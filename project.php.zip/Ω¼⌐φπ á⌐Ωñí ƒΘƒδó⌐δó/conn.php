<?php

$conn= mysqli_connect("localhost","root","","car");
if ($conn===false){
	die ("error".mysqli_connect_error());
}

?>  